import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;

import hsa_ufa.Console;

class MazeGame{
	static Console c; // The output console
	final static ImageIcon IMAGE = new ImageIcon ("mario.png");//The image of the player
	final static ImageIcon IMAGE2 = new ImageIcon ("Maze1.jpg"); //Background image of the menu
	final static ImageIcon IMAGE3 = new ImageIcon ("Maze2.jpg"); //Background image during the levels.
	
	
	//This is the method which displays the menu
	public static void menu() throws InterruptedException, UnsupportedAudioFileException, IOException, LineUnavailableException {
		boolean finished = false;
	
			
		
		c.clear();//clear screen
		c.drawImage(IMAGE2.getImage(),0,0,c.getWidth(),c.getHeight());//Draws the background for the menu
		
		//Display the choices the user has for the levels.
		while(!finished) {
			c.setColor(Color.RED);
			c.setFont(new Font("jokerman",Font.PLAIN,60));
			c.drawString("MAZE RUNNER", c.getWidth()/2 - 225 ,c.getHeight()/2 - 200);
			
			c.setColor(Color.RED);
			c.setFont(new Font("Verdana",Font.PLAIN,40));
			c.drawString(" LEVEL 1", c.getWidth()/2 - 110 ,c.getHeight()/2 - 100);
			
			c.setColor(Color.RED);
			c.setFont(new Font("Verdana",Font.PLAIN,40));
			c.drawString(" LEVEL 2", c.getWidth()/2 - 110 ,c.getHeight()/2  );
			
			c.setColor(Color.RED);
			c.setFont(new Font("Verdana",Font.PLAIN,40));
			c.drawString(" LEVEL 3", c.getWidth()/2 - 110 ,c.getHeight()/2 + 100 );
		
			c.setColor(Color.RED);
			c.setFont(new Font("Verdana",Font.PLAIN,40));
			c.drawString("Press q to quit", c.getWidth() - 400 ,c.getHeight() - 100 );
			
			char choice = c.getKeyChar();//player input t choose the levels
		
		//Chooses the level
		switch (choice) {
		case '1':
		gameplay(Levels.level1(),20,20);//Level 1 size of squares is 20 
		break;
		
		case '2':
		gameplay(Levels.level2(),14,14);//Level 2 size of squares is 14
		break;
		
		case '3':
			gameplay(Levels.level3(),8,8);//Level 3 size of squares is 8
			break;	
			
		case 'q':
			c.close();
			break;
		}
	}
}
	//This method draws the mazes and also has the character movement and collision statements.
	public static void gameplay(int arr[][],int mazeSquareSize,int playerSize)throws InterruptedException, UnsupportedAudioFileException, IOException, LineUnavailableException {
		// Making the program play sound
		File soundFile = new File("Sound.wav");
			AudioInputStream sound = AudioSystem.getAudioInputStream(soundFile);

			// load the sound into memory (a Clip)
			DataLine.Info info = new DataLine.Info(Clip.class, sound.getFormat());
			Clip clip = (Clip) AudioSystem.getLine(info);
			clip.open(sound); 
			clip.start();
		c.clear();
		int playerKeyCode;//the variable for the controls
		//These two variables are needed to draw the maze
	    int i;
		int j = 0;
		//These two variables track the position of the player
		int xCor = 0;
		int yCor = 0;
		
		//This decides whether the game is over or not
		boolean done = false;
		c.drawImage(IMAGE3.getImage(),0,0,c.getWidth(),c.getHeight());//Draws the background for the gameplay
		while(!done) {
			
			Thread.sleep(1000/17);//17 frames per second
			char playerQuitCode;
			
			//If the player presses b during a level the game will go back to the menu;
			playerQuitCode = c.getKeyChar();
		    if(playerQuitCode == 'b' || playerQuitCode == 'B') {
		    	done = true;
		    	clip.stop();
		    }
		   //If the user presses q at any time the program will stop
		    if(playerQuitCode == 'q' || playerQuitCode == 'Q') {
		    	c.close();
		    	clip.stop();
		    }
					
			playerKeyCode = c.getKeyCode();//Reads the user's controls
			//Draws the maze
			for ( i = 0; i < arr.length; i++) {
				for ( j = 0; j < arr[0].length; j++) {
					
					if (arr[i][j] == 1) {//Draws the walls of the maze
						c.setColor(Color.BLACK);
						c.fillRect( j * mazeSquareSize, i * mazeSquareSize, mazeSquareSize, mazeSquareSize);

					}
					if(arr[i][j]==0) {//Draws the white spaces where the player can move to
						c.setColor(Color.WHITE);
						c.fillRect(j * mazeSquareSize, i * mazeSquareSize, mazeSquareSize, mazeSquareSize);
						
					}
					
					
					if(arr[i][j]== 3) {//Draws the player as a red square
						c.setColor(Color.RED);
						c.fillRect(j * mazeSquareSize, i * mazeSquareSize, mazeSquareSize, mazeSquareSize);
						//Reads the location of the player
						xCor = j;
						yCor = i;
						//If the player reaches the end of the maze, the game stops.
						if(arr[yCor + 1][xCor] == 4 || arr[yCor - 1][xCor] == 4 || arr[yCor][xCor + 1] == 4 || arr[yCor ][xCor- 1] == 4){
							done=true;
							clip.stop();
						}
					}
				
					
				}
			}
			if (playerKeyCode == Console.VK_RIGHT) {//Movement if right arrow is pressed
				if(arr[yCor][xCor + 1] == 0 ||arr[yCor][xCor + 1] == 4)//Not letting the player go through walls
				{arr[yCor][xCor] = 0;//Making the square where the player previously was white.
				arr[yCor][xCor + 1] = 3;
				}
			}
			if (playerKeyCode == Console.VK_LEFT) {//Movement if left arrow is pressed
				if(arr[yCor][xCor - 1] == 0 || arr[yCor][xCor - 1] == 4)//Not letting the player go through walls
				{arr[yCor][xCor] = 0;//Making the square where the player previously was white.
				arr[yCor][xCor - 1] = 3;
				}
			}
			if(playerKeyCode == Console.VK_DOWN) {//Movement if down arrow is pressed
				if(arr[yCor + 1][xCor ] == 0 || arr[yCor + 1][xCor ] == 4)//Not letting the player go through walls
				{arr[yCor][xCor] = 0;//Making the square where the player previously was white.
				arr[yCor + 1][xCor] = 3;
				}
			}
			if (playerKeyCode == Console.VK_UP) {//Movement if up arrow is pressed
				if(arr[yCor - 1][xCor] == 0 || arr[yCor - 1][xCor ] == 4)//Not letting the player go through walls
					{
				arr[yCor][xCor] = 0;//Making the square where the player previously was white.
				arr[yCor - 1][xCor] = 3;
				}
				
			}
		}
		menu(); //Shows the menu.
	}
	
	public static void main(String[] args)throws InterruptedException, UnsupportedAudioFileException, IOException, LineUnavailableException{
		c = new Console(1000,640,"MAZE RUNNER");//making a console window 1000 x 640. 

		menu();//Display the menu
		
		
		
	}
}

		
	

